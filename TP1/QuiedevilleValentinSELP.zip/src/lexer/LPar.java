package lexer;

public class LPar implements Token {

    @Override
    public String toString(){
        return"(";
    }
}
