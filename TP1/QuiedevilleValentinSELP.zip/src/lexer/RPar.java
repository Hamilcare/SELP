package lexer;

public class RPar implements Token {
    @Override
    public String toString(){
        return ")";
    }
}
