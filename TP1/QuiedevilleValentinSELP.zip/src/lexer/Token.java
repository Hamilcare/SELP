package lexer;

public interface Token {
    @Override
    String toString();
}
