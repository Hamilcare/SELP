package parser.exception;

public class UnknownOperatorException extends Exception {
    public UnknownOperatorException(){
        super("Unknown Operator");
    }
}
