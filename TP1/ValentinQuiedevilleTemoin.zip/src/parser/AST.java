package parser;

public abstract class AST {
    public abstract String toString();
}
