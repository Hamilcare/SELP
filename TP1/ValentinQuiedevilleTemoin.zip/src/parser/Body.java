package parser;

import lexer.Token;

public class Body extends AST{

    public static Body parse (Token t) throws Exception {
        return null;
    }


    @Override
    public String toString() {
        return null;
    }
}
