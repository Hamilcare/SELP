package lexer;

public class If implements Token {
    @Override
    public String toString(){
        return "If";
    }
}
