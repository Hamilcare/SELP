package lexer;

public class Defvar implements Token {
    @Override
    public String toString() {
        return "="  ;
    }
}
