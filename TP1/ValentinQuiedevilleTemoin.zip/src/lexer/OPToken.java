package lexer;

public enum OPToken implements Token {
    PLUS,
    MINUS,
    TIMES,
    DIVIDE,
    EQUAL,
    LESS;
}
