La piste verte est faite.
Tous les tests de la piste verte et les tests errors passent.
L'utilisation de la console java comme entrée pour le programme ne semble pas fonctionner.


